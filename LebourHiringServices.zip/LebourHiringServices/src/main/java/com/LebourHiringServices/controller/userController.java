package com.LebourHiringServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LebourHiringServices.entites.user;
import com.LebourHiringServices.model.userDTO;
import com.LebourHiringServices.service.userService;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;
@RestController
@RequestMapping("/api")
public class userController {
	@Autowired
	private userService Userservice;
	@Autowired
	private Converter converter;
	@PostMapping("/createemployee")
	ResponseEntity<userDTO>createuser(@Valid @RequestBody userDTO userdto)
	{
		final user users = converter.converTouserEntity(userdto);
		return new ResponseEntity<userDTO>(Userservice.registeruser(users), HttpStatus.CREATED);
	}
	@GetMapping("/GetAlluser")
	List<userDTO>getAlluser()
	{
		return Userservice.getAlluser();
	}
	@GetMapping("/getuserById/{usr_id}")
	userDTO getuserById(@PathVariable("eid")int user_id) {
		return Userservice.getuserById(user_id);
	}
	@PutMapping("/updateuser/{user_id}")
		userDTO updateuser(@Valid @PathVariable int user_id, @RequestBody userDTO userdto) {
		final user users = converter.converTouserEntity(userdto);
		return Userservice.updateuser(user_id, users);
		}
	@DeleteMapping("/deleteuser/{id}")
	String deleteuser(@PathVariable int user_id) {
		return Userservice.deleteuser(user_id);
	}
	
}
