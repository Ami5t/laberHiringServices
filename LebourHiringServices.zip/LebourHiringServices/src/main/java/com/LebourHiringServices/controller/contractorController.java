package com.LebourHiringServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.LebourHiringServices.entites.contractor;
import com.LebourHiringServices.model.contractorDTO;
import com.LebourHiringServices.service.contractorService;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;

public class contractorController {
	@Autowired
	private contractorService contractorservice;
	@Autowired
	private Converter converter;
	@PostMapping("/createcontractor")
	
	ResponseEntity<contractorDTO>createcontractor(@Valid @RequestBody contractorDTO contractordto)
	{
		final contractor Contractor = converter.converTocontractorEntity(contractordto);
		return new ResponseEntity<contractorDTO>(contractorservice.registercontractor(Contractor), HttpStatus.CREATED);
	}
	@GetMapping("/GetAllcontractor")
	List<contractorDTO>getAllcontractor()
	{
		return contractorservice.getAllcontractor();
	}
	@GetMapping("/getcontractorById/{id}")
	contractorDTO getcontractorById(@PathVariable("contractor_id")int contractor_id) {
		return contractorservice.getcontractorById(contractor_id);
	}
	@PutMapping("/updatecontractor/{id}")
	contractorDTO updatecontractor(@Valid @PathVariable int contractor_id, @RequestBody contractorDTO contractordto) {
	final contractor Contractor = converter.converTocontractorEntity(contractordto);
	return contractorservice.updatecontractor(contractor_id, Contractor);
	}
	@DeleteMapping("/deletecontractor/{contractor_id}")
	String deletecontractor(@PathVariable int contractor_id) {
		return contractorservice.deletecontractor(contractor_id);
	}
}
