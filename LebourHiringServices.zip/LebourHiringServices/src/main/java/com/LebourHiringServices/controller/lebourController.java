package com.LebourHiringServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LebourHiringServices.entites.Lebour;
import com.LebourHiringServices.model.LebourDTO;
import com.LebourHiringServices.service.LebourServices;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;
@RestController
@RequestMapping("/api")
public class lebourController {
	@Autowired
	private LebourServices lebourservices ;
	@Autowired
	private Converter converter;
	@PostMapping("/createLebour")
	ResponseEntity<LebourDTO>createLebour(@Valid @RequestBody LebourDTO lebourdto)
	{
		final Lebour lebours = converter.converToLebourEntity(lebourdto);
		return new ResponseEntity<LebourDTO>(lebourservices.registerLebour(lebours), HttpStatus.CREATED);
	}
	
	@GetMapping("/GetAllLebour")
	List<LebourDTO>getAllLebour()
	{
		return lebourservices.getAllLebour();
	}
	
	@GetMapping("/getLebourById/{Lebour_id}")
	LebourDTO getLebourById(@PathVariable("Lid")int Lebour_id) {
		return lebourservices.getLebourById(Lebour_id);
	}
	
	@PutMapping("/updateLebour/{Lebour_id}")
		LebourDTO updateLebour(@Valid @PathVariable int Lebour_id, @RequestBody LebourDTO lebourdto) 
	{
		final Lebour Lebour = converter.converToLebourEntity(lebourdto);
		return lebourservices.updateLebour(Lebour_id, Lebour);
	}
	
	@DeleteMapping("/deleteLebour/{Lebour_id}")
	String deleteLebour(@PathVariable int Lebour_id) 
	{
		return lebourservices.deleteLebour(Lebour_id);
	}
}
