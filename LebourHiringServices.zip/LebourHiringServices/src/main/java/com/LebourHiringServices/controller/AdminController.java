package com.LebourHiringServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LebourHiringServices.model.AdminDTO;
import com.LebourHiringServices.service.AdminService;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class AdminController {
	@Autowired
	private AdminService adminservice;
	@Autowired
	private Converter converter ;
	
	@PostMapping("/createAdmin")
	ResponseEntity<AdminDTO>createAdmin(@Valid @RequestBody AdminDTO admindto){
		final com.LebourHiringServices.entites.Admin admin = converter.convertToAdminEntity(admindto);
		return new ResponseEntity<AdminDTO>(adminservice.registerAdmin(admin),HttpStatus.CREATED);
	}
	@GetMapping("/GetAllAdmins")
	List<AdminDTO> getAllAdmins()
	{
		return adminservice.getAllAdmins();
	}
	@GetMapping("/getAdminById/{Admin_id}")
	AdminDTO getAdminById(@PathVariable("Admin_id")int Admin_id) {
		return adminservice.getAdminById(Admin_id);
	}
	    @PutMapping("/updateAdmin/{Admin_id}")
		AdminDTO updateAdmin(@Valid @PathVariable int Admin_id,@RequestBody AdminDTO admindto) {
			final com.LebourHiringServices.entites.Admin admin = converter.convertToAdminEntity(admindto);
			return adminservice.updateAdmin(Admin_id,admin);
		}
	
	@DeleteMapping("/deleteAdmin/{id}")
	String deleteAdmin(@PathVariable int Admin_id) {
		return adminservice.deleteAdmin(Admin_id);
	}
}
