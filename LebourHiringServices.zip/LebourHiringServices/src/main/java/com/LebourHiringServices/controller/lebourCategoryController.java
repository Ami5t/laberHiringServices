package com.LebourHiringServices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LebourHiringServices.entites.lebourCategory;
import com.LebourHiringServices.model.lebourCategoryDTO;
import com.LebourHiringServices.service.lebourCategoryService;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class lebourCategoryController {
	@Autowired
	private lebourCategoryService lebourcategoryservice;
	@Autowired
	private Converter converter;
	
	@PostMapping("/createlebourCategory")
	ResponseEntity<lebourCategoryDTO>createlebourCategory(@Valid @RequestBody lebourCategoryDTO lebourCategoryDTO){
		final lebourCategory lebourcat = converter.converTolebourCategoryEntity(lebourCategoryDTO);
		return new ResponseEntity<lebourCategoryDTO>(lebourcategoryservice.addlebourCategory(lebourcat),HttpStatus.CREATED);
	}
	@GetMapping("/getAlllebourCategory")
	List<lebourCategoryDTO> getAlllebourCategory(){
		return lebourcategoryservice.getAlllebourCategories();
	}
	@GetMapping("/getlebourCategoryById/{category_id}")
	lebourCategoryDTO getlebourCategoryById(@PathVariable("jcid")int category_id) {
		return lebourcategoryservice.getlebourCategoryDTOById(category_id);
	}
	@PutMapping("/updatelebourCategory/{id}")
	lebourCategoryDTO updatelebourCategoryDTO(@Valid @PathVariable int category_id, @RequestBody lebourCategoryDTO lebourCategoryDTO)
	{
		final lebourCategory jobcat = converter.converTolebourCategoryEntity(lebourCategoryDTO);
		return lebourcategoryservice.updatelabourCategoryDTO(category_id, jobcat);
	}
	@DeleteMapping("/deletelebourCategory/{category_id}")
	String deletelebourCategory(@PathVariable int category_id) {
		return lebourcategoryservice.deletelabourCategoryDTO(category_id);
	}
}
