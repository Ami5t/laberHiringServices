package com.LebourHiringServices.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LebourHiringServices.entites.lebourCategory;
import com.LebourHiringServices.exception.ResourceNotFoundException;
import com.LebourHiringServices.model.lebourCategoryDTO;
import com.LebourHiringServices.repository.lebourCategoryRepository;
import com.LebourHiringServices.service.lebourCategoryService;
import com.LebourHiringServices.util.Converter;

@Service
public class lebourCategoryImpl implements lebourCategoryService {
	@Autowired
	private lebourCategoryRepository LabourCategoryRepository;
	@Autowired
	private Converter converter;
	@Override
	public lebourCategoryDTO addlebourCategory(lebourCategory LebourCategory) {
		lebourCategory lebourcategory = LabourCategoryRepository.save(LebourCategory);
		return converter.ConvertTolebourCategoryDTO(lebourcategory);
	}
	@Override
	public List<lebourCategoryDTO>getAlllebourCategories(){
		List<lebourCategory>jc = LabourCategoryRepository.findAll();
		List<lebourCategoryDTO>jcc = new ArrayList<>();
		for(lebourCategory jcg : jc) {
			jcc.add(converter.ConvertTolebourCategoryDTO(jcg));
		}
		return jcc;
	}
	@Override
	public lebourCategoryDTO updatelebourCategory(int category_id, lebourCategory LebourCategory) {
		lebourCategory jc = LabourCategoryRepository.findById((long) category_id).orElseThrow(()->
		new ResourceNotFoundException("leabourCategory","category_id",category_id));
		return converter.ConvertTolebourCategoryDTO(jc);
	}
	@Override
	public lebourCategoryDTO getlebourCategoryById(int category_id) {
		lebourCategory jc = LabourCategoryRepository.findById((long) category_id).orElseThrow(()->
		new ResourceNotFoundException("jobCategory","Id",category_id));
		return converter.ConvertTolebourCategoryDTO(jc);
	}
	@Override
	public String deletelebourCategory(int category_id) {
		LabourCategoryRepository.findById((long)category_id).orElseThrow(()->
		new ResourceNotFoundException("lebourCategory","Id",category_id));
		LabourCategoryRepository.deleteById((long) category_id);
		return "Job Category has been removed succeessfully!";
	}
	
}
