package com.LebourHiringServices.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LebourHiringServices.entites.Admin;
import com.LebourHiringServices.exception.ResourceNotFoundException;
import com.LebourHiringServices.model.AdminDTO;
import com.LebourHiringServices.repository.AdminRepository;
import com.LebourHiringServices.service.AdminService;
import com.LebourHiringServices.util.Converter;



@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private Converter converter;
	
	@Override
	public AdminDTO registerAdmin(Admin admin) 
	{
		Admin admn = adminRepository.save(admin);
		return converter.ConvertToAdminDTO(admn);
	}
	
	@Override
	public List<AdminDTO>getAllAdmins(){
		List<Admin> admin = adminRepository.findAll();
		//lest of type DTO
		List<AdminDTO> dtoList = new ArrayList<>();
		for(Admin s: admin) {
			dtoList.add(converter.ConvertToAdminDTO(s));
		}
		return dtoList;
	}
	
	@Override
	public AdminDTO getAdminById(int Admin_id) {
		Admin a = adminRepository.findById((long) Admin_id).orElseThrow(()->
		new ResourceNotFoundException("admin","Admin_Id",Admin_id));
		return converter.ConvertToAdminDTO(a);
	}
	
	@Override
	public AdminDTO updateAdmin(int Admin_id, Admin admin) {
		Admin a = adminRepository.findById((long)Admin_id).orElseThrow(()->
		new ResourceNotFoundException("Admin","Admin_Id",Admin_id));
		a.setAdmin_id(admin.getAdmin_id());
		a.setEmail(admin.getEmail());
		a.setPassword(admin.getPassword());
		Admin admn = adminRepository.save(a);
		return converter.ConvertToAdminDTO(admin);
	}
	
	@Override
	public String deleteAdmin(int Admin_id) {
		adminRepository.findById((long)Admin_id).orElseThrow(()->
		new ResourceNotFoundException("Admin","Admin_Id",Admin_id));
		adminRepository.deleteById((long) Admin_id);
		return "Admin got deleted successfully!";
	}
}
