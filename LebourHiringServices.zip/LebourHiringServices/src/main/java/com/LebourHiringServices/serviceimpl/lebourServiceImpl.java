package com.LebourHiringServices.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LebourHiringServices.entites.Lebour;
import com.LebourHiringServices.exception.ResourceNotFoundException;
import com.LebourHiringServices.model.LebourDTO;
import com.LebourHiringServices.repository.LebourRepository;
import com.LebourHiringServices.service.LebourServices;
import com.LebourHiringServices.util.Converter;

@Service
public class lebourServiceImpl implements LebourServices{
	@Autowired
	private LebourRepository labourRepository;
	@Autowired
	private Converter converter;
	@Override
	
	public LebourDTO registerLebour(Lebour lebour) {
		Lebour lebours=labourRepository.save(lebour);
		return converter.ConvertToLebourDTO(lebours);
	}
	@Override
	public List<LebourDTO> getAllLebour() {
		List<Lebour> lebour=labourRepository.findAll();
		
		//list of type DTO
		List<LebourDTO> dtoList=new ArrayList<>();
		for(Lebour e:lebour)
		{
			dtoList.add(converter.ConvertToLebourDTO(e));
		}
		
		return dtoList;
	}
	@Override
	public LebourDTO getLebourById(int Lebour_id) {
		Lebour e=labourRepository.findById((long)Lebour_id).orElseThrow(()->
		new ResourceNotFoundException("Lebour", "Lebour_Id", Lebour_id));
		return converter.ConvertToLebourDTO(e);
    }
	@Override
	public LebourDTO updateLebour(int Lebour_id, Lebour lebour ) {
		Lebour e=labourRepository.findById((long)Lebour_id).orElseThrow(()->
		new ResourceNotFoundException("Lebour", "Lebour_Id", Lebour_id));
		e.setLebour_name(lebour.getLebour_name());
		e.setLebour_address(lebour.getLebour_address());
		e.setLebour_degination(lebour.getLebour_degination());
		e.setContact_no(lebour.getContact_no());
		e.setEmail(lebour.getEmail());
		e.setPassword(lebour.getPassword());
		e.setLabourCategory(lebour.getLabourCategory());
		Lebour lebours=labourRepository.save(e);
		return converter.ConvertToLebourDTO(lebours);
	}
	@Override
	public String deleteLebour(int Lebour_id) {
		labourRepository.findById((long)Lebour_id).orElseThrow(()->
		new ResourceNotFoundException("Lebour", "Lebour_Id", Lebour_id));
		
		labourRepository.deleteById((long)Lebour_id);
		return "Lebour got deleted successfully!!";
				
	}
}
