package com.LebourHiringServices.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LebourHiringServices.entites.Lebour;
import com.LebourHiringServices.entites.contractor;
import com.LebourHiringServices.exception.ResourceNotFoundException;
import com.LebourHiringServices.model.LebourDTO;
import com.LebourHiringServices.model.contractorDTO;
import com.LebourHiringServices.repository.LebourRepository;
import com.LebourHiringServices.repository.contractorRepository;
import com.LebourHiringServices.service.contractorService;
import com.LebourHiringServices.util.Converter;

@Service
public class contractorServiceImpl implements contractorService{
	@Autowired
	private contractorRepository ContractorRepository;
	
	@Autowired
	private Converter converter;
	
	@Override
	public contractorDTO registercontractor(contractor Contractor) 
	{
		contractor contract=ContractorRepository.save(Contractor);
		return converter.ConvertTocontractorDTO(contract);
	}
	@Override
	public List<contractorDTO> getAllcontractor() {
		List<contractor> contract=ContractorRepository.findAll();
		
		//list of type DTO
		List<contractorDTO> dtoList=new ArrayList<>();
		for(contractor c:contract)
		{
			dtoList.add(converter.ConvertTocontractorDTO(c));
		}
		
		return dtoList;
	}
	@Override
	public contractorDTO getcontractorById(int contractor_id) 
	{
		contractor contract=ContractorRepository.findById((long)contractor_id).orElseThrow(()->
		new ResourceNotFoundException("contractor", "contractor_Id", contractor_id));
		return converter.ConvertTocontractorDTO(contract);
    }
	@Override
	public contractorDTO updatecontractor(int contractor_id, contractor contract) {
		contractor e=ContractorRepository.findById((long)contractor_id).orElseThrow(()->
		new ResourceNotFoundException("contractor", "Lebour_Id", contractor_id));
		e.setContractor_id(contract.getContractor_id());
		e.setContractor_Name(contract.getContractor_Name());
		e.setCompany_Name(contract.getCompany_Name());
		e.setContact_no(contract.getContact_no());
		e.setEmail(contract.getEmail());
		e.setPassword(contract.getPassword());
		contractor contracts=ContractorRepository.save(e);
		return converter.ConvertTocontractorDTO(contracts);
	}
	@Override
	public String deletecontractor(int contractor_id) {
		ContractorRepository.findById((long)contractor_id).orElseThrow(()->
		new ResourceNotFoundException("contractor", "contractor_id", contractor_id));
		{
		ContractorRepository.deletecontractor((long)contractor_id);
		return "Contractor got deleted successfully!!";
		}	
	}
}
