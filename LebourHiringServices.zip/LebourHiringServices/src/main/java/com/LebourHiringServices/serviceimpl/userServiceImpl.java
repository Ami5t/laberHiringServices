package com.LebourHiringServices.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.LebourHiringServices.entites.user;
import com.LebourHiringServices.model.userDTO;
import com.LebourHiringServices.service.userService;
import com.LebourHiringServices.util.Converter;

import jakarta.validation.Valid;
@Service
public class userServiceImpl {
	@Autowired
	private userService UserService;
	@Autowired
	private Converter converter;
	
	@PostMapping("/createuser")
	ResponseEntity<userDTO>createuser(@Valid @RequestBody userDTO userdto)
	{
		final user User = converter.converTouserEntity(userdto);
		return new ResponseEntity<userDTO>(UserService.registeruser(User), HttpStatus.CREATED);
	}
	
	@GetMapping("/GetAlluser")
	List<userDTO>getAllEmployees()
	{
		return UserService.getAlluser();
	}
	
	@GetMapping("/getuserById/{User_id}")
	userDTO getuserById(@PathVariable("eid")int User_id) {
		return UserService.getuserById(User_id);
	}
	
	@PutMapping("/updateuser/{User_id}")
	userDTO updateuser(@Valid @PathVariable int User_id, @RequestBody userDTO userdto) {
	final user User = converter.converTouserEntity(userdto);
	return UserService.updateuser(User_id, User);
	}
	
	@DeleteMapping("/deleteuser/{User_id}")
	String deleteuser(@PathVariable int User_id) {
		return UserService.deleteuser(User_id);
	}
}
