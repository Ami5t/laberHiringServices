package com.LebourHiringServices.service;

import java.util.List;

import com.LebourHiringServices.entites.lebourCategory;
import com.LebourHiringServices.model.lebourCategoryDTO;



public interface lebourCategoryService {
	
	lebourCategoryDTO addlebourCategory(lebourCategory lebourCategory);
	List<lebourCategoryDTO> getAlllebourCategories();
	lebourCategoryDTO getlebourCategoryDTOById(int category_id);
	lebourCategoryDTO updatelabourCategoryDTO(int category_id, lebourCategory lebourCategory);
	String deletelabourCategoryDTO(int category_id);
}
