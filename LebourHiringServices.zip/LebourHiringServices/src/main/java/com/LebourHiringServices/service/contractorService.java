package com.LebourHiringServices.service;

import java.util.List;

import com.LebourHiringServices.entites.contractor;
import com.LebourHiringServices.model.contractorDTO;

public interface contractorService {
	contractorDTO registercontractor(contractor contractor);
	List<contractorDTO>getAllcontractor();
	contractorDTO getcontractorById(int contractor_id);
	contractorDTO updatecontractor(int contractor_id, contractor contractor);
	String deletecontractor(int contractor_id);
}
