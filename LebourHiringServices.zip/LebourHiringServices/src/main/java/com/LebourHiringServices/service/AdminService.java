package com.LebourHiringServices.service;

import java.util.List;

import com.LebourHiringServices.entites.Admin;
import com.LebourHiringServices.model.AdminDTO;


public interface AdminService {
	AdminDTO registerAdmin(Admin admin);
	List<AdminDTO> getAllAdmins();
	AdminDTO getAdminById(int Admin_id);
	AdminDTO updateAdmin(int Admin_id, Admin admin);
	String deleteAdmin(int Admin_id);
}
