package com.LebourHiringServices.service;

import java.util.List;

import com.LebourHiringServices.entites.Lebour;
import com.LebourHiringServices.model.LebourDTO;


public interface LebourServices {
	LebourDTO registerLebour(Lebour Lebour );
	List<LebourDTO> getAllLebour();
	LebourDTO getLebourById(int Lebour_id);
	LebourDTO updateLebour(int Lebour_id, Lebour Lebour);
	String deleteLebour(int Lebour_id);
}
