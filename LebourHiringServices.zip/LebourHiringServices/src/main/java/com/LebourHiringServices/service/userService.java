package com.LebourHiringServices.service;

import java.util.List;

import com.LebourHiringServices.entites.user;
import com.LebourHiringServices.model.userDTO;

public interface userService {
	userDTO registeruser( user user);
	List<userDTO> getAlluser();
	userDTO getuserById(int user_id);
	userDTO updateuser(int user_id, user user);
	String deleteuser(int user_id);
}
