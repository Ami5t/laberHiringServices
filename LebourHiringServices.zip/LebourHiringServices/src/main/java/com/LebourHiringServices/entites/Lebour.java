package com.LebourHiringServices.entites;






import java.util.ArrayList;
import java.util.List;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Lebour {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Lebour_Id;
	@Column(length = 50)
	private String Lebour_name;
	@Column(length = 100)
	private String lebour_address;
	@Column(length = 100)
	private String lebour_degination;
	@Column(length = 20)
	private int Contact_no;
	@Column(unique = true)
    private String email;
    @Column(unique = true)
    private String password;
    
	private boolean status = Boolean.TRUE;
	
	
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	 @JoinColumn(name = "category_id")
	private lebourCategory labourCategory;
	
	  @ManyToOne
	    @JoinColumn(name = "user_id")
	    private user User;
	  
	  @ManyToOne
	    @JoinColumn(name = "contractor_id")
	    private contractor Contractor;
}
