package com.LebourHiringServices.entites;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Setter
 @Getter
@NoArgsConstructor
@AllArgsConstructor
public class contractor {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long contractor_id;
	@Column(length = 100)
    private String Contractor_Name;
	@Column(length = 100)
    private String company_Name;
	@Column(length = 20)
	private int Contact_no;
    @Column(unique=true)
    private String email;
    @Column(nullable=false)
    private String password;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private user user;
    
    @OneToMany(mappedBy = "contractor")
    private List<Lebour> lebours;
    
    
}
