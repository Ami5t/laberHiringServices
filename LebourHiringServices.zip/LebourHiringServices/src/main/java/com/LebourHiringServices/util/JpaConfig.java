package com.LebourHiringServices.util;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

public class JpaConfig {
	@Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource) {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource);
        em.setPackagesToScan("com.onlinejobportal.entities");

        // Specify Hibernate as the JPA provider
        em.setPersistenceProviderClass(org.hibernate.jpa.HibernatePersistenceProvider.class);

        return em;
    }
}
