package com.LebourHiringServices.util;

import org.springframework.beans.BeanUtils;

import com.LebourHiringServices.entites.Admin;
import com.LebourHiringServices.entites.Lebour;
import com.LebourHiringServices.entites.contractor;
import com.LebourHiringServices.entites.lebourCategory;
import com.LebourHiringServices.entites.user;
import com.LebourHiringServices.model.AdminDTO;
import com.LebourHiringServices.model.LebourDTO;
import com.LebourHiringServices.model.contractorDTO;
import com.LebourHiringServices.model.lebourCategoryDTO;
import com.LebourHiringServices.model.userDTO;

public class Converter {
	//convert from DTO to entity
		public Admin convertToAdminEntity(AdminDTO admindto) {
			Admin admin = new Admin();
			if(admindto!=null) {
				BeanUtils.copyProperties(admindto, admin);
			}
			return admin;
		}
		
		public AdminDTO ConvertToAdminDTO(Admin admin) {
			AdminDTO admindto = new AdminDTO();
			if(admin!=null) {
				BeanUtils.copyProperties(admin, admindto);
			}
			return admindto;
		}
		public Lebour converToLebourEntity(LebourDTO lebourdto) {
			Lebour lebour = new Lebour();
			if(lebour!=null) {
				BeanUtils.copyProperties(lebourdto, lebour);
			}
			return lebour;
		}
		
		public LebourDTO ConvertToLebourDTO(Lebour lebour) {
			LebourDTO lebourdto = new LebourDTO();
			if(lebour!=null) {
				BeanUtils.copyProperties(lebour, lebourdto);
			}
			return lebourdto;
		}
		public contractor converTocontractorEntity(contractorDTO contractordto) {
			contractor Contractor = new contractor();
			if(contractordto!=null) {
				BeanUtils.copyProperties(contractordto,Contractor);
			}
			return Contractor;
		}
		
		public contractorDTO ConvertTocontractorDTO(contractor Contractor) {
			contractorDTO ContractorDTO = new contractorDTO();
			if(Contractor!=null) {
				BeanUtils.copyProperties(Contractor, ContractorDTO);
			}
			return ContractorDTO;
		}
		public user converTouserEntity(userDTO Userdto) {
			user User = new user();
			if(Userdto!=null) {
				BeanUtils.copyProperties(Userdto,User);
			}
			return User;
		}
		
		public userDTO ConvertTouserDTO(user User) {
			userDTO Userdto = new userDTO();
			if(Userdto!=null) {
				BeanUtils.copyProperties(User, Userdto);
			}
			return Userdto;
		}
		public lebourCategory converTolebourCategoryEntity(lebourCategoryDTO LebourCategorydto ) {
			lebourCategory LebourCategory = new lebourCategory();
			if(LebourCategory!=null) {
				BeanUtils.copyProperties(LebourCategorydto,LebourCategory);
			}
			return LebourCategory;
		}
		
		public lebourCategoryDTO ConvertTolebourCategoryDTO(lebourCategory LebourCategoryDTO) {
			lebourCategoryDTO LebourCategorydto = new lebourCategoryDTO();
			if(LebourCategorydto!=null) {
				BeanUtils.copyProperties(LebourCategoryDTO, LebourCategorydto);
			}
			return LebourCategorydto;
		}
		
}
