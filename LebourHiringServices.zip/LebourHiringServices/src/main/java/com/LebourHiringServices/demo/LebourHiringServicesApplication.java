package com.LebourHiringServices.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LebourHiringServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LebourHiringServicesApplication.class, args);
		System.out.println("Welcome to naka lebours Services");
	}

}
