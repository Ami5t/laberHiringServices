package com.LebourHiringServices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.LebourHiringServices.entites.user;



public interface userRepository extends JpaRepository<user,Long> {

}
