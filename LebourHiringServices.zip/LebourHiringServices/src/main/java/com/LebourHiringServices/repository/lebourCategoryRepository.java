package com.LebourHiringServices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.LebourHiringServices.entites.lebourCategory;



public interface lebourCategoryRepository  extends JpaRepository<lebourCategory, Long>{

}
