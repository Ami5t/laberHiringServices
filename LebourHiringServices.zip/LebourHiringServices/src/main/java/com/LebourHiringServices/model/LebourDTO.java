package com.LebourHiringServices.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class LebourDTO {
	@NotNull
	private Long Lebour_id;
	@NotNull
	@Size(max=50)
	private String Lebour_name;
	@NotNull
	@Size(max=50)
	private String lebour_address;
	@NotNull
	@Size(max=50)
	private String lebour_degination;
	@NotNull
	@Size(max=10)
	private int Contact_no;
	@NotNull
	private String email;
	@NotNull
	private String password;
}
