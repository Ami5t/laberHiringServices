package com.LebourHiringServices.model;



import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class AdminDTO {
	@Id
	@NotNull
	private Long Admin_id;
	@NotNull
	@Size(min=3,max=40,message="Enter email address")
	private String email;
	@NotNull
	@Size(min=5,max=20,message="Password should contain minimum 5 letters")
	private String password;
}
