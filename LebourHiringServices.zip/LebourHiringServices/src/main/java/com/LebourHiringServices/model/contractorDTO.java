package com.LebourHiringServices.model;

import jakarta.persistence.Column;

public class contractorDTO {
         private Long contractor_id;
    
         private String Contractor_Name;
    
         private String company_Name;
         @Column(unique=true)
          private String email;
         @Column(nullable=false)
          private String password;
    
}
