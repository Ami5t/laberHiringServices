package com.LebourHiringServices.model;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
public class userDTO {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Lebour_Id;
	@Column(length = 50)
	private String Lebour_name;
	@Column(length = 100)
	private String lebour_address;
	@Column(length = 100)
	private String lebour_degination;
	@Column(unique = true)
	private String phNo;
	private boolean status=Boolean.TRUE;
}
