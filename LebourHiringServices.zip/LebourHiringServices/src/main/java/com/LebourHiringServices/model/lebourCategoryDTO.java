package com.LebourHiringServices.model;

import java.util.ArrayList;
import java.util.List;

import com.LebourHiringServices.entites.Lebour;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

public class lebourCategoryDTO {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long category_id;
 	@Column(nullable = false, unique = true)
    private String category_name;
 	@OneToMany(mappedBy = "LebourCategory")
 	private List<Lebour> lebourc = new ArrayList<>();
}
